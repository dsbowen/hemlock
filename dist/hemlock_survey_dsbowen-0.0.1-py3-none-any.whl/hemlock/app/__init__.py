"""Application factory, settings, statics, and templates"""

from hemlock.app.factory import create_app, db, socketio
from hemlock.app.settings import Settings