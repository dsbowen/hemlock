"""Custom database types"""

from hemlock.database.types.data_frame import DataFrame, DataFrameType