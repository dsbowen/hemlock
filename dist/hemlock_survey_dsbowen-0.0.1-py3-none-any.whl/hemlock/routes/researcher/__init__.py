"""Researcher routes"""

import hemlock.routes.researcher.login
import hemlock.routes.researcher.status
import hemlock.routes.researcher.download
import hemlock.routes.researcher.profile